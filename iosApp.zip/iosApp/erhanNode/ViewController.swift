//
//  ViewController.swift
//  erhanNode
//
//  Created by erhan demirci on 30.10.2024.
//


import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var messageTextField: UITextField!
    
    let baseURL = "http://localhost:3000/messages"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchMessages()
    }
    
    @IBAction func sendMessage(_ sender: UIButton) {
        guard let message = messageTextField.text, !message.isEmpty else { return }
        sendMessageToServer(message: message)
        messageTextField.text = ""
        fetchMessages()
    }
    
    func fetchMessages() {
        let url = URL(string: baseURL)!
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error fetching messages: \(error)")
                return
            }
            
            guard let data = data else { return }
            
            do {
                // JSON verisini bir dizi olarak çözümleyin
                if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [[String: Any]] {
                    let messages = json.compactMap { $0["message"] as? String } // Mesajları al
                    DispatchQueue.main.async {
                        self.textView.text = messages.joined(separator: "\n")
                    }
                } else {
                    print("Unexpected JSON format")
                }
            } catch {
                print("Error parsing JSON: \(error)")
            }
        }.resume()
    }



    
    func sendMessageToServer(message: String) {
        // Send a message to the server
        guard let url = URL(string: baseURL) else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Mesajı bir JSON nesnesi olarak oluşturun
        let json: [String: Any] = ["message": message]
        
        do {
            // JSON verisini encode edin
            let jsonData = try JSONSerialization.data(withJSONObject: json, options: [])
            request.httpBody = jsonData
            
            // İstek gönderin
            URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    print("Error sending message: \(error)")
                    return
                }
                // İsteğin başarılı olup olmadığını kontrol edin
                if let httpResponse = response as? HTTPURLResponse {
                    if httpResponse.statusCode == 200 {
                        print("Message sent successfully")
                    } else {
                        print("Error: Server responded with status code \(httpResponse.statusCode)")
                    }
                }
            }.resume()
            
        } catch {
            print("Error encoding JSON: \(error)")
        }
    }

}
